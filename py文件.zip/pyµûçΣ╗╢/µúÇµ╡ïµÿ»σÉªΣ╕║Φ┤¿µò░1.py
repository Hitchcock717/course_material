a = int(input("请输入一个数字："))
j = 2
for i in range(j,a):
    if a % i == 0:
        print("%s不是一个质数" % a)
        print("%s乘%s等于%s" % (i, a//i, a))
        break
    else:
        j += 1
        if j == a:
            print("%s是一个质数" % a)67