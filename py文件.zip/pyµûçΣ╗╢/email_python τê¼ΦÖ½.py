import smtplib
from email.mime.text import MIMEText
from bs4 import BeautifulSoup
from urllib.request import urlopen
import time


EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'zhaobowen9876@gmail.com'
EMAIL_HOST_PASSWORD = '87537277abc'
EMAIL_USE_TLS = True
EMAIL_USE_SSL = False

def sendmail(subject,body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = 'zhaobowen9876@gmail.com'
    msg['To'] = '841057707@qq.com'


s = smtplib.SMTP('localhost')
s.send_message(msg)
s.quit()

bsObj = BeautifulSoup(urlopen("https://isitchristmas.com/"))
while bsObj.find("a",{"id":"answer"}).attrs['title'] == "NO":
    print("It is not Christmas yet.")
    time.sleep(20)
bsObj = BeautifulSoup(urlopen("https://isitchristmas.com/"))
sendmail("It's Christmas!",
         "According to http://itischristmas.com,it is Christmas!")