#_*_ coding:utf-8 _*_
i = 1
while True:
    if i % 2 ==1:
        print(i)
    i += 1
    if i > 100:
        break
