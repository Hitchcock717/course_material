row = 1
for row in range(10):
    col = 1
    while col <= row:
        print("%d * %d = %d\t" % (col,row,row*col),end="")
        col += 1
    print()
    row += 1

for i in range(1,10):
    for j in range(1,10):
        print('{} * {} = {}'.format(i,j,i*j))


