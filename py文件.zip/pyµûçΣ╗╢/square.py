import turtle
turtle.bgcolor('yellow')
turtle.color('red','red')
for i in range(360):
    turtle.setheading(i)
    for i in range(5):
        turtle.fd(100)
        turtle.left(72)
