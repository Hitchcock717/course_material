from bs4 import BeautifulSoup
import this
soup = BeautifulSoup
print(type(soup))