i = 1
while i <= 100:
    if (i % 7 ==0 or i %10 == 7 or i//10 == 7):
        i = i + 1
        continue
    else:
        print(i, end=",")



num = int(input("请输入一个数字: "))

if num > 1:
    for i in range(2,num):
        if (num % i) == 0:
            print(num, "不是质数")
            print(i, "乘于",num//i, "是",num)
            break
        else:
            print(num, "是质数")
else:
    print(num,"不是质数")