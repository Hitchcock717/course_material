#测试未来孩子的身高
num1=input('请输入您的身高')
num2=input('请输入您男/女朋友的身高')
sum=int(num1)+int(num2)
print(num1,'+',num2,'=',sum)
print(sum*(1.11)/(2))