i = 1
while i <= 100:
    if (i % 7 ==0 or i %10 == 7 or i//10 == 7):
        i = i + 1
        continue
    else:
        print(i, end=",")
        i = i + 1
