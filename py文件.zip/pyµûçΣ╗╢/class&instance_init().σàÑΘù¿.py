class CocaCola:
    formula = ['caffeine','sugar','water','soda']

    def __init__(self):

        for element in self.formula:
            print('Coke has {}!'.format(element))

    def drink(self):
        print('Energy!')


coke = CocaCola()
coke.drink()