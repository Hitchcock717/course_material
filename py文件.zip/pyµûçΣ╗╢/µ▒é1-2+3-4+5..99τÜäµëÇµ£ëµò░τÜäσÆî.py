s = ""
i = 1
sum = 0
while i < 100:
    if i % 2 == 1:
        if i == 1:
            s = str(i)
        else:
            s = s + "+" + str(i)
        sum = sum + i
    else:
        s = s + "-" + str(i)
        sum = sum - i
    i += 1
print(s)
print(sum)