a = int(input("请输入一个数字："))
j = 2
if a > 1:
    if a % j ==0:
        print(a,"不是质数")
    else:
        for i in range(j,a):
            if a % i == 0:
                print(a, "不是质数")
                print("%s乘%s等于%s",(i,a//i,a))
            else:
                print(a,"是质数")
else:
    print(a,"不是质数")