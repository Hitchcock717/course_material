import re
file_input=open('/Users/felix_zhao/Desktop/软件竞赛资料汇总/语料库文本/渣打银行.txt','r',encoding='utf-8')
file_output=open('/Users/felix_zhao/Desktop/软件竞赛资料汇总/语料库文本/渣打银行.txt','a')
read_file =str(file_input.read())
print(read_file)
pattern=re.compile(r'[0-9]')
new_text=pattern.findall(read_file)
write_string=file_output.write('I want to')
print(write_string)