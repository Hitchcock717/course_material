#一对兔子每月生一对兔子，刚出生的兔子两个月后才能生育

a = 2
b = 2
sum = 0
for i in range(1,21):
    print("第", i, "个月")
    a = b
    b = sum
    sum = a + b
    print("有", sum, "个兔子")
print("一共有", sum, "个兔子")