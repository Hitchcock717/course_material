# coding:utf-8
import turtle as t
t.goto(0,0)
t.pendown()
t.pensize(15)
t.pencolor('green')
t.circle(100)


