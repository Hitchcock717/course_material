import random
secretNumber = random. randint(1,3)
print('I was thinking of a number between 1 and 100.')

for guessTaken in range(1,11):
    print('Take a guess.')
    guess = int(input())

    if guess < secretNumber:
        print('The number is too low.')
    elif guess > secretNumber:
        print('The number is too high.')
    else:
        break

if guess == secretNumber:
    if guessTaken != 1:
        print('You have guessed the number in ' + str(guessTaken) + ' guesses! ')
    else:
        print('You have guessed the number in ' + str(guessTaken) + ' guess! ')
else:
    print('Nope! The number I was thinking of was ' + str(secretNumber))
