import http.client
import time
import random


def get_time(host):
    conn = http.client.HTTPConnection(host)
    conn.request("GET", "/")
    r = conn.getresponse()
    # 获取http头date部分
    nt = r.getheader("date")
    # 将GMT时间转换成时间元组
    gmt_time = time.strptime(nt, "%a, %d %b %Y %H:%M:%S %Z")
    # 换算成北京时间时间戳
    bj_sec = time.mktime(gmt_time) + 8*60*60
    # 转化成北京时间可读形式
    bj_time = time.strftime("%a, %d %b %Y %H:%M:%S", time.localtime(bj_sec))
    print("现在北京时间：", bj_time)
    return bj_sec


def my_shuffle(name_list):
    random.shuffle(name_list)
    i = 0
    for name in name_list:
        i = i + 1
        print("%d.%s" % (i, name), end=" ")
        if i % 10 == 0:
            print("")
    print("")


if __name__ == "__main__":
    list1 = ["周慧文", "熊冠铭", "范佳慧", "杨荣兵", "张祎轩", "刘朦"]
    list2 = ["惠普", "邓云瀚", "赖其才"]
    list3 = ["吕媛", "邱越", "陳靖雅", "赵博文", "叶佳琦", "张悦", "胡育嘉", "龚润宇", "曾月清", "许运丰", "马航航", "徐嘉辰",
             "屈仟", "张偲", "柳俊志", "张彦男", "焦凯旋", "章焕", "刘旭德", "强力", "徐钰伟", "杜笑宇", "吴雅萱", "孟繁玉",
             "王智伟", "昝志浩", "邹浩", "胡颖聪", "孙尚维", "周晋峰（博雅四苑）"]
    tt = "Tue, 29 Nov 2018 11:22:00"
    print("目标北京时间：", tt)
    target_time = time.strptime(tt, "%a, %d %b %Y %H:%M:%S")
    while True:
        now_time = get_time("www.baidu.com")
        # 转换为时间戳后，相减
        sec = time.mktime(target_time) - now_time
        if sec == 0:
            print("周三：")
            my_shuffle(list1)
            my_shuffle(list2)
            print("周日：")
            my_shuffle(list3)
            break
        elif sec > 10:
            time.sleep(10)
        else:
            time.sleep(1)

# format格式如下：
#     %a      本地(local)简化星期名称
#     %A      本地完整星期名称
#     %b      本地简化月份名称
#     %B      本地完整月份名称
#     %c      本地相应的日期和时间表示
#     %d      一个月中的第几天(01-31)
#     %H      一天中的第几个小时(24小时制，00-23)
#     %l      一天中的第几个小时(12小时制，01-12)
#     %j      一年中的第几天(01-366)
#     %m      月份(01-12)
#     %M      分钟数(00-59)
#     %p      本地am或者pm的相应符
#     %S      秒(01-61)
#     %U      一年中的星期数(00-53,星期天是一个星期的开始,第一个星期天之前的所有天数都放在第０周)
#     %w      一个星期中的第几天(0-6,0是星期天)
#     %W      和%U基本相同，不同的是%W以星期一为一个星期的开始
#     %x      本地相应日期
#     %X      本地相应时间
#     %y      去掉世纪的年份(00-99)
#     %Y      完整的年份
#     %z      用+HHMM或者-HHMM表示距离格林威治的时区偏移(H代表十进制的小时数，M代表十进制的分钟数)
#     %Z      时区的名字(如果不存在为空字符)
#     %%      %号本身
#             %p只有与%I配合使用才有效果
#             当使用strptime()函数时，只有当在这年中的周数和天数被确定的时候%U和%W才会被计算
