import string
path = '/Users/felix_zhao/Desktop/Walden.txt'

#利用string模块中的punctuation功能去除标点符号，lower()函数去除大写，建立集合去除重复词汇，构建dict、使用键值对打印结果
with open(path,'r') as text:
    words = [raw_word.strip(string.punctuation).lower() for raw_word in text.read().split()]
    words_index = set(words)
    counts_dict = {index: words.count(index) for index in words_index}


for word in sorted(counts_dict,key=lambda x: counts_dict[x], reverse=True):
    print('{}--{} times'.format(word, counts_dict[word]))