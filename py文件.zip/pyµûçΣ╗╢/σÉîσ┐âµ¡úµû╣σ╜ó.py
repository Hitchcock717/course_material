import turtle
for i in range(4):
    #t.penup()
    #t.goto(0,0)
    turtle.forward(300)
    turtle.left(90)
    turtle.pendown()
turtle.penup()
turtle.goto(50,50)
turtle.pendown()
for i in range(4):
    turtle.forward(200)
    turtle.left(90)
turtle.penup()
turtle.goto(100,100)
turtle.pendown()
for i in range(4):
    turtle.forward(100)
    turtle.left(90)
turtle.penup()
turtle.goto(125,125)
turtle.pendown()
for i in range(4):
    turtle.forward(50)
    turtle.left(90)
turtle.penup()
turtle.goto(137.5,137.5)
turtle.pendown()
for i in range(4):
    turtle.forward(25)
    turtle.left(90)
