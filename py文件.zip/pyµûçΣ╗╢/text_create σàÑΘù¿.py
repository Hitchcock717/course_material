def text_creation():
    path = '/Users/felix_zhao/Desktop/py文件/'
    for name in range (1,11):
        with open(path + str(name) + '.txt','w') as text:
            text.write(str(name))
            text.close()
            print('Done')
text_creation()