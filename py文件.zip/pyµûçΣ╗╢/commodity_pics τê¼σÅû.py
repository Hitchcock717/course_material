#正则表达式与Beautifulsoup结合
from urllib.request import urlopen
from bs4 import BeautifulSoup
import re

html = urlopen("http://www.pythonscraping.com/pages/page3.html")
bsObj = BeautifulSoup(html)
images = bsObj.findAll("img",{"src":re.compile("\.\.\/img\/gifts\/img.*\.jpg")})
for image in images:
    print(image["src"]) #打印出图片的相对路径

# 获取标签对象属性 (myTag.attrs)
# 获取图片资源位置 （myImgTag.attrs["src"])

# lambda表达式   soup.findaAll(lambda tag:len(tag.attrs)=2)