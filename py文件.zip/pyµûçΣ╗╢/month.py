#month.py
months="JanFebMarAprMayJunJulAugSepOctNovDec"
n=input("plz input month(1-12) :")
pos=(int(n)-1) * 3
monthAbbrev=months[pos:pos+3]
print("abbreviation of month is" +monthAbbrev+".")
